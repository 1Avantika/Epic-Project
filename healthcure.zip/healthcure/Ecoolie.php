<!DOCTYPE html>
<? include config.php ?>
<html>
    <head>
        <title>Healthcure</title>
        <meta charset="UTF-8">
        <meta name="keywords" content="coolie booking">
        <meta name="description" content="book coolie">
        
        
        
        <style>.emo:hover{width:"auto"; height:30%;}</style>
        <style>.em:hover{width:"auto"; height:30%;} </style>
        <style>.eml:hover{width:"auto"; height:30%;} </style>
        <style>#ima{background-image: url('/spiral.png'); padding:80px; background-size:50%;background-repeat:no-repeat;}</style>
        
       
    </head>
    <div id="ima"> <h1 align="center" ><pre>Welcome to HEALTHCURE!</pre></h1><br><br><br><br><br>
       </div>

    <body>
    
        <header>
        
            <div align="center" >
            
            
            
                    
                    
                       <br>
                        <h1>Patient</h1>
                        <a href=/login.php ><img class="emo" src="/patient.png" width="460" height="460"></a> 
                        <br>
                        <h1>Healthcare</h1>
                        <a href=/login.php><img class="em" src="/heal.jpg" width="450" height="500"></a>
                        <br>
                        <h1>Hospital</h1>
                        <a href=/login.php><img class="eml" src="/hos.png" width="470" height="440"></a>
                       
                    
           
                     
          
                
                
                
         
        
        </header>

          
         
          
          
    </body>
 </html>